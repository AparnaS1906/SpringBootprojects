package com.hcl.emailvalidator;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.hcl.emailvalidator.model.EmailValidator;
import com.hcl.emailvalidator.repository.EmailRepository;
import com.hcl.emailvalidator.service.EmailService;




@SpringBootTest
class EmailValidatorApplicationTests {
	

	 @InjectMocks
	private EmailService emailService;

	 @Mock
	private EmailRepository emailRepository;

	 EmailValidator emailvalidator1, emailvalidator2, emailvalidator3, emailvalidator4;

	 @BeforeEach
	public void setUp()
	{
	//For Successful output
		 emailvalidator1 = new EmailValidator("123456", "NL91RABO0315273638", "aparnajs12@gmail.com");
	//For duplicate account
		 emailvalidator2 = new EmailValidator("123457", "NL91RABO0315273638", "appu@gmail.com");
	//For duplicate emailId
		 emailvalidator3 = new EmailValidator("123458", "NL91RABO0315273639", "appu@gmail.com");
	//For incorrect emailId
		 emailvalidator4 = new EmailValidator("123459", "NL91RABO0315273632", "nandha19gmail.com");

	 }
	@Test
	public void validateTest() {

	 Mockito.when(emailRepository.save(emailvalidator1)).thenReturn(emailvalidator1);
	Assertions.assertEquals(emailService.createEmailValidator(emailvalidator1),emailvalidator1);

	 Mockito.when(emailRepository.save(emailvalidator2)).thenReturn(emailvalidator2);
	Assertions.assertEquals(emailService.createEmailValidator(emailvalidator2),emailvalidator2);

	 Mockito.when(emailRepository.save(emailvalidator3)).thenReturn(emailvalidator3);
	Assertions.assertEquals(emailService.createEmailValidator(emailvalidator3),emailvalidator3);

	 Mockito.when(emailRepository.save(emailvalidator4)).thenReturn(emailvalidator4);
	Assertions.assertEquals(emailService.createEmailValidator(emailvalidator4),emailvalidator4);
	
	}
	}

