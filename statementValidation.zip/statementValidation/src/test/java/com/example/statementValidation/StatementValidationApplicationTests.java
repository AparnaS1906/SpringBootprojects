package com.example.statementValidation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.statementValidation.model.StatementVal;
import com.example.statementValidation.repository.StatementRepository;
import com.example.statementValidation.service.StatementService;


@SpringBootTest
class StatementValidationApplicationTests {

	@InjectMocks
	private StatementService statementService;

	@Mock
	private StatementRepository statementRepository;

	StatementVal statement1,statement2,statement3,statement4;

	@BeforeEach
	public void setUp()
	{	
		//For Successful output
		statement1 = new StatementVal("123456", "AB12123412341234", "Flowers from Ram", 100, -50, 50);
		//For duplicate reference
		statement2 = new StatementVal("123456", "AB12123412341234", "Clothes from Ram", 100, -50, 50);
		//For incorrect end balance
		statement3 = new StatementVal("123456", "AB00123412341234", "Clothes from Ram", 100, -50, 100);
		//for duplicate reference and inncorrect end balance
		statement4 = new StatementVal("123456", "AB00123412341234", "Clothes from Ram", 100, -50, 100);

	}
	@Test
	public void validateTest() {

		Mockito.when(statementRepository.save(statement1)).thenReturn(statement1);
		Assertions.assertEquals(statementService.createStatement(statement1), statement1);
		//Assertions.assertEquals("http://localhost:8080/api/validation",HttpStatus.OK);
	}
	@Test
	public void validateTest1() {

		Mockito.when(statementRepository.save(statement2)).thenReturn(statement2);
		Assertions.assertEquals(statementService.createStatement(statement2), statement2);
		//Assertions.assertEquals("http://localhost:8080/api/validation",HttpStatus.OK);
	}
	@Test
	public void validateTest2() {

		Mockito.when(statementRepository.save(statement3)).thenReturn(statement3);
		Assertions.assertEquals(statementService.createStatement(statement3), statement3);
		//Assertions.assertEquals("http://localhost:8080/api/validation",HttpStatus.OK);
	}
	@Test
	public void validateTest3() {

		Mockito.when(statementRepository.save(statement4)).thenReturn(statement4);
		Assertions.assertEquals(statementService.createStatement(statement4), statement4);
		//Assertions.assertEquals("http://localhost:8080/api/validation",HttpStatus.OK);
	}

}
