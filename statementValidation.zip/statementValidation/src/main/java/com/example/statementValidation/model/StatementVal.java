package com.example.statementValidation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity 
//@Data //lombok annotation
@Table(name="Bank_Statement",uniqueConstraints = @UniqueConstraint(columnNames = "Transaction_reference"))

public class StatementVal {

	@Id //To specify Primary key
	@NotNull //Reference cannot be null
	//@Pattern(regexp="^[0-9]{6}")//It contains 0-9 and must have 6 digits
	@Column(name="Transaction_reference")//To specify column name
	private String reference;

	@NotNull//Account Number should not be null
	@Pattern(regexp="^[A-Z0-9]{16,20}")//Account Number must be IBAN
	@Size(min = 16, max=20, message = "Account Number should be valid")
	@Column(name="Account_number")
	private String accNumber;

	@Column(name="Description")
	private String description;

	@Column(name="Start_Balance")
	private int startBalance;

	@Column(name="Mutation")
	private int mutation;

	@Column(name="End_Balance")
	private int endBalance;

	public StatementVal() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StatementVal(@NotNull String reference,
			@NotNull @Pattern(regexp = "^[A-Z0-9]{16,20}") @Size(min = 16, max = 20, message = "Account Number should be valid") String accNumber,
			String description, int startBalance, int mutation, int endBalance) {
		super();
		this.reference = reference;
		this.accNumber = accNumber;
		this.description = description;
		this.startBalance = startBalance;
		this.mutation = mutation;
		this.endBalance = endBalance;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStartBalance() {
		return startBalance;
	}

	public void setStartBalance(int startBalance) {
		this.startBalance = startBalance;
	}

	public int getMutation() {
		return mutation;
	}

	public void setMutation(int mutation) {
		this.mutation = mutation;
	}

	public int getEndBalance() {
		return endBalance;
	}

	public void setEndBalance(int endBalance) {
		this.endBalance = endBalance;
	}

	
}
