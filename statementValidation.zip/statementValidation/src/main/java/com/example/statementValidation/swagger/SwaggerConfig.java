package com.example.statementValidation.swagger;

import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2 //For enabling Swagger
public class SwaggerConfig {

	public Docket satatementApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("Statement-API")
				.select().apis(RequestHandlerSelectors.basePackage("com.hcl.statementValidator.controller"))
				.build();

	}

	


}
