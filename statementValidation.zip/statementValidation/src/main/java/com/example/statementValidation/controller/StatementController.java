package com.example.statementValidation.controller;

import java.util.Map;
import java.util.WeakHashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.statementValidation.model.StatementVal;
import com.example.statementValidation.service.StatementService;




@RestController
@RequestMapping("/api")
public class StatementController {

	@Autowired
	private StatementService statementService;
	@PostMapping("validation")
	public ResponseEntity<Object> validate(@Valid @RequestBody StatementVal statementVal){
		Map<String, String> weakHasMap=new WeakHashMap<String, String>();
		
		//To check whether reference is duplicate or not
		if(statementService.getStatementByReference(statementVal.getReference())) {
			//Reference is not duplicate
			
			//To check whether End balance is correct or not
			if(statementService.checkBalance(statementVal.getEndBalance(),
					statementVal.getStartBalance(), statementVal.getMutation())) {
				//Correct End balance
				
				statementService.createStatement(statementVal);//Saves in DB
				weakHasMap.put("result", "SUCCESSFUL");
				weakHasMap.put("errorRecords", "");
				return new ResponseEntity<Object>(weakHasMap,HttpStatus.OK);
			}
			else {
				//Incorrect end balance
				
				statementService.createStatement(statementVal);
				weakHasMap.put("result", "INCORRECT_END_BALANCE");
				weakHasMap.put("errorRecords"," " +statementService.errorData(statementVal.getReference(), 
						statementVal.getAccNumber()));	
				return new ResponseEntity<Object>(weakHasMap,HttpStatus.OK);
			}
		}
		else {
			//Reference is duplicate
			//To check whether end balance is correct or not
			if(statementService.checkBalance(statementVal.getEndBalance(),
					statementVal.getStartBalance(), statementVal.getMutation())) {
				//Correct End balance
				
				statementService.createStatement(statementVal);
				weakHasMap.put("result", "DUPLICATE_REFERENCE");
				weakHasMap.put("errorRecords"," " +statementService.errorData(statementVal.getReference(), 
						statementVal.getAccNumber()));
				return new ResponseEntity<Object>(weakHasMap,HttpStatus.OK);
			}

			else {
				//Incorrect End balance
				
				statementService.createStatement(statementVal);
				weakHasMap.put("result", "DUPLICATE_REFERENCE_INCORRECT_END_BALANCE");
				weakHasMap.put("errorRecords"," " +statementService.errorData(statementVal.getReference(), 
						statementVal.getAccNumber()));
				return new ResponseEntity<Object>(weakHasMap,HttpStatus.OK);
			}

		}

	}
}
