package com.example.statementValidation.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.statementValidation.model.StatementVal;
import com.example.statementValidation.repository.StatementRepository;



@Service
public class StatementService {

	@Autowired
	private StatementRepository statementRepository;
	public StatementVal createStatement(StatementVal statementVal) {
		return statementRepository.save(statementVal);
	}
	
	public Boolean getStatementByReference(String reference) {
		StatementVal statement1 = statementRepository.findByReference(reference);
		if(statement1==null) {
			return true;
		}
		else {
			return false;
		}
}
	public Boolean checkBalance(int endBalance,int startBalance, int mutation) {

		if(endBalance == startBalance + mutation){
			return true;
		}
		else if (endBalance == startBalance - mutation) {
			return true;
		}
		else {
			return false;
		}
	}
	public ArrayList<String> errorData(String reference, String accountNumber) {	

		ArrayList<String> errorList = new ArrayList<String>();
		errorList.add("reference:" +reference);
		errorList.add("accountNumber:" +accountNumber);

		return errorList;
	}
}