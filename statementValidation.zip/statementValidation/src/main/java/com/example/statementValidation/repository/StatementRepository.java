package com.example.statementValidation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.statementValidation.model.StatementVal;


public interface StatementRepository extends JpaRepository<StatementVal, String>{
	
StatementVal findByReference(String reference); 
	
	//To get Start balance
	StatementVal findByStartBalance(int startBalance); 
	
	//To get Mutation
	StatementVal findByMutation(int mutation); 
	
	//To get End balance
	StatementVal findByEndBalance(int endBalance); 

}
