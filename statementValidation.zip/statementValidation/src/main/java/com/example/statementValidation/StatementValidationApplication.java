package com.example.statementValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatementValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatementValidationApplication.class, args);
	}

}
